import { About } from '@/components/sections/About'
import { Contact } from '@/components/sections/Contact'
import { Footer } from '@/components/sections/Footer'
import { Hero } from '@/components/sections/Hero'
import { Portfolio } from '@/components/sections/Portfolio'
import { Services } from '@/components/sections/Services'
import { Testimonials } from '@/components/sections/Testimonials'
import { Container } from '@/components/ui/Container'
import { SectionHeading } from '@/components/ui/SectionHeading'
import { getHomeContent } from '@/lib/content'

/**
 * Statically rendered; the revalidation hooks refresh it when content changes.
 * Social is a placeholder until Phase 7.
 */
function SocialPlaceholder() {
  return (
    <section id="social" aria-labelledby="social-heading" className="py-section">
      <Container>
        <SectionHeading id="social-heading" eyebrow="Social" title="Follow along" description="Coming soon." />
      </Container>
    </section>
  )
}

export default async function HomePage() {
  const { site, hero, about, portfolio, services, testimonials } = await getHomeContent()

  const sections = [
    'about',
    ...(portfolio.photos.length > 0 ? ['portfolio'] : []),
    ...(services.length > 0 ? ['services'] : []),
    ...(testimonials.length > 0 ? ['testimonials'] : []),
  ]

  return (
    <>
      <main id="main">
        <Hero hero={hero} fallbackHeading={site.siteTitle} />
        <About about={about} />
        <Portfolio photos={portfolio.photos} categories={portfolio.categories} />
        <Services services={services} />
        <Testimonials testimonials={testimonials} />
        <SocialPlaceholder />
        <Contact site={site} services={services} />
      </main>
      <Footer site={site} sections={sections} />
    </>
  )
}
